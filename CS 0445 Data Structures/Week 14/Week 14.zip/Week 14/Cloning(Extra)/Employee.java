// CS 0445 Spring 2018
// Simple class to demonstrate Cloning, and the implications of making
// a "shallow copy".

public class Employee implements Comparable<Employee>, Cloneable
{
	private String name;
	private float salary;
	private StringBuilder job;

	public Employee(String s, float sal, String j)
	{
		name = new String(s);
		salary = sal;
		job = new StringBuilder(j);
	}

	public void setSalary(float newSal)
	{
		salary = newSal;
	}

	// This mutates the job StringBuilder within the Employee.  Note that it is 
	// not reassigning the job, just altering the current one.  Thus, a shallow
	// copy of an Employee will be affected by this change.
	public void appendJob(String s)
	{
		job.append(s);
	}

	// Compare based on salary
	public int compareTo(Employee rhs)
	{
		if (salary > rhs.salary)
			return 1;
		else if (salary < rhs.salary)
			return -1;
		else
			return 0;
	}

	// Note the syntax here -- see also Java Interlude 9 of the Carrano text
	public Object clone()
	{
		Employee c = null;
		try
		{
			c = (Employee) super.clone();
		}
		catch (CloneNotSupportedException e)  // This exception is a checked
							// exception in Java and therefore must be handled
							// within the clone method
		{
			System.out.println("Cannot clone " + this);
		}
		c.name = new String(this.name);
		c.salary = this.salary;
		c.job = this.job; // This is SHALLOW, since we are not making a copy of
		                  // the StringBuilder -- rather we are just copying a
		                  // reference to it.  If we wanted to make this clone
						  // deeper we could create a new StringBuffer and copy
						  // the old data into it.
		return c;
	}

	public String toString()
	{
		return "Name: " + name + " Salary: " + salary + " Job: " + job;
	}
}
