// CS 0445 Spring 2018
// Demo of how integrity of collections can be destroyed by mutating objects,
// and how clones can be made of objects

import java.util.*;
import TreePackage.*;

public class Example15
{
	// Use an iterator to output the contents of a BST using an
	// inOrder traversal
	public static void showInorder(BinarySearchTree<Employee> T)
	{
		Iterator<Employee> I = T.getInorderIterator();
		while (I.hasNext())
		{
			Employee E = I.next();
			System.out.println(E);
		}
	}

	public static void main(String [] args)
	{
		// Make a new BST and add some Employees to it
		BinarySearchTree<Employee> T = new BinarySearchTree<Employee>();
		Employee E1 = new Employee("Herb", 50000, "Lawyer");
		Employee E2 = new Employee("Mort", 100000, "Doctor");
		Employee E3 = new Employee("Abby", 75000, "Analyst");
		Employee E4 = new Employee("Marge", 40000, "Technician");
		Employee E5 = new Employee("Ingmar", 25000, "Civil Servant");
		Employee E6 = new Employee("Hector", 60000, "Teacher");

		T.add(E1); T.add(E2); T.add(E3); T.add(E4); T.add(E5); T.add(E6);

		System.out.println("BST Inorder Traversal: ");
		showInorder(T);
		System.out.println();

		// Keeping the original reference, mutate two of the employees
		E2.setSalary(1111);
		E5.setSalary(2222222);

		// Now the BST is NOT ACTUALLY a BST anymore!
		System.out.println("Mutated objects cause it to no longer be a BST:");
		showInorder(T);
		System.out.println();

		// Clone the employees
		Employee E7 = (Employee) E2.clone();
		Employee E8 = (Employee) E5.clone();

		// Set back the originals to where they were -- this does not affect
		// the clones
		E2.setSalary(100000);
		E5.setSalary(25000);

		// Change the jobs in the originals -- this WILL affect the clones because
		// we are simply mutating the job field and the copy is shallow.
		E2.appendJob(" is fun");
		E5.appendJob(" is fun");

		System.out.println("Object values mutated back and also mutated:");
		showInorder(T);
		System.out.println();

		System.out.println(E7);
		System.out.println(E8);
	}
}


